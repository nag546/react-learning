import React, { Component } from "react";

const PrintMessage = ({ message }) => (
  <div className="container">{message}</div>
);
export default PrintMessage;
