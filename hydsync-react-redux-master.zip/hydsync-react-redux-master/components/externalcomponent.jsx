import React, { Component } from 'react';

class ExternalComponent extends Component {
   
    render() { 
        return (
            <div>
              <h4>I am External Component</h4>
            </div>
        );
    }
}
 
export default ExternalComponent;