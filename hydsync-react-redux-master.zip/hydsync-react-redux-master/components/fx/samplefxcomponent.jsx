import React, { Component } from "react";
const Print = ({ message }) => <div className="container">{message}</div>;
export default Print;
