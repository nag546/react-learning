// describe('Meaningful Test', () => {
//     it('1 + 1 => 2', () => {
//         expect(1 + 1).toBe(2);
//     });
// });

//require('./../app/components/componentfortest/app.component.data.spec');
//require('./../app/components/empcomponent/app.emp.component.spec');
